#!/usr/bin/env bash

# 安装 lnmp 环境
./uninstall.sh lnmp
./install.sh lnmp
chkconfig nginx on
chkconfig php-fpm on
