#!/usr/bin/env bash

# 启动 php
if [[ -f /usr/bin/php ]]; then
    echo "重启 php-fpm"
    /etc/init.d/php-fpm restart
fi

# 启动 nginx
if [[ -f /usr/bin/nginx ]]; then
    echo "重启 nginx"
    /etc/init.d/nginx restart
fi

nginx -g "daemon off;"
